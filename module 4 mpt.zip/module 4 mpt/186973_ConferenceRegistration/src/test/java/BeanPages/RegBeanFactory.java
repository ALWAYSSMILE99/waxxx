package BeanPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegBeanFactory {

	@FindBy(id = "txtName")
	WebElement ApplicantName;

	@FindBy(id = "txtFirstName")
	WebElement firstName;

	@FindBy(id = "txtLastName")
	WebElement lastName;

	



	@FindBy(id = "txtMobileNo")
	WebElement mobileNo;

	@FindBy(id = "txtEmail")
	WebElement mailId;


	/*
	 * @FindBy(xpath = "/html/body/form/table/tbody/tr[11]/td[2]") WebElement
	 * communication;
	 */
	
	/*
	 * @FindBy(id = "txtLndLine") WebElement residencyAdd;
	 */
	
	@FindBy(id="btnSubmit")
	WebElement SubmitButton;
	
	/*
	 * @FindBy(id="btnReset") WebElement ResetButton;
	 */
	

	public RegBeanFactory() {
		
	}

	public String getApplicantName() {
		return this.ApplicantName.getAttribute("value");
	}

	public void setApplicantName(String ApplicantName) {
		this.ApplicantName.sendKeys(ApplicantName);
	}

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	


	public String getMobileNo() {
		return this.mobileNo.getAttribute("value");
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getMailId() {
		return this.mailId.getAttribute("value");
	}


	public void setMailId(String mailId) {
		this.mailId.sendKeys(mailId);
	}
	
	


	/*
	 * public void clickCommunication() { communication.click(); }
	 */
	public void clickNextButton() {
		SubmitButton.click();
	}

	/*
	 * public String getResidencyAdd() { return
	 * this.residencyAdd.getAttribute("value"); }
	 * 
	 * public void setResidencyAdd(String residencyAdd) {
	 * this.residencyAdd.sendKeys(residencyAdd); }
	 */
	/*
	 * public void clickResetButton() { ResetButton.click(); }
	 */

}
