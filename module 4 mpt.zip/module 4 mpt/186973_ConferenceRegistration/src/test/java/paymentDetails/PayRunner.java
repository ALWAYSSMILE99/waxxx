package paymentDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},monochrome=true,
features= {"C:\\Users\\vbikkavi\\Desktop\\module 4 mpt\\186973_ConferenceRegistration\\src\\test\\java\\Features\\PaymentDetails.feature"},
glue= {"paymentDetails"})
public class PayRunner {

}
